# Lab 5

1. 육면체 Box 클래스 정의 
  * 멤버변수: length, width, height (모두 실수)
  * 멤버 함수
    - 각 값이 주어지면 주어진 값으로 초기화하고 값이 주어지지 않으면 0으로 초기화
    - double getVolume() 멤버함수 : 부피를 구해 반환
    - void scalel(double s) 멤버함수: length, width, height를 s 배 중가

2. Template로 구현하여야 할 함수를 정의하고 각 자료형에 대해서 함수 호출해서 template 함수의 정의를 확인하시오. (add와 sum 함수 이외의 함수)


3. Array 클래스를 template 클래스로 구현하시오.


4. 다음과 같은 템플릿 스택이 정의되어 있다. 
  * 스택: 나중에 저장된 것이 먼저 반환되는 자료구조 
  * 예: 빈 스택에 push(3), push(4), push(5)하면 세 개의 데이터 값이 순서대로 저장된 후
    pop()하면 5 반환, pop()하면 4 반환, pop() 하면 3 반환 
    
```cpp
template <typename T>
class Stack 
{
T *data;          // 동적할당한 저장 공간의 시작 주소 저장
public:
 Stack(int m);    // m: 할당한 저장장소의 크기, 저장공간 m개를 동적 할당 
 ~Stack();        // 동적 할당한 저장공간 해지
 T pop();         //최근에 저장된 데이터를 반환
void push(T x);   // 입력 데이터 x 를 저장공간이 저장 
void print();     // 저장된 모든 데이터를 화면에 출력
};
```
5. 예외 처리와 관련하여 try, catch, throw의 키위드를 사용하는 프로그램을 작성하시오.

