# Polymorphism(다형성)

## 학습 목표

* 다형성의 개념을 이해하고 적용할 수 있다.
* 동적 바인딩의 개념을 이해한다. 
* 상향 형변환의 개념을 이해한다.
* 가상 함수의 개념을 이해한다.


## 학습 내용

* [다형성의 개념](./Concept.md)
* [가상 함수와 동적 바인딩](./VirtualFunction.md)
* [가상 소멸자](./virtual_destructor.md)
* [순수 가상 함수](./pureVirtualFunc.md)
* [프로그램 실습](./Labs.md)
* [프로그램 문제](./Problems.md)
